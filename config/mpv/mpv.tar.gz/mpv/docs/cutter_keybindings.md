# --- // Cutter:
cut_movie : cut time point,default key 'c'
log_time_queue : print the queue that record the cut point,defalut key 'l'
output_queue : output video,default key 'o'
set_fromStart : reset,and set the first cut point(left trim) in 0 second,default key 'r'
set_End : set the right trim in the end time of the video,default key 'v'
acu_output_queue : accurate time cut 'b'
undo : undo 'u'
