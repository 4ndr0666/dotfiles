local socket = require("socket")
print("LuaSocket is installed and working!")
