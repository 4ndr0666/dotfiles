// ==UserScript==
// @name         Auto best quality for videos in Google Photos
// @namespace    mikulas.zelinka.dev
// @version      0.1
// @description  Tampermonkey script that selects the best quality for all embedded youtube videos when the page/player is loaded (at least those that are served with the same URL as those in Google Photos).
// @author       Mikuláš Zelinka
// @match        https://youtube.googleapis.com/embed/*
// @grant        none
// ==/UserScript==

var player;
const targetQuality = 'best';
// const targetQuality = 'hd1080';

function findPlayer() {
    player = document.querySelector('.html5-video-player');
    if (player && (player.getPlaybackQuality() != 'unknown') ) {
        // console.log('found video player:', player);
        console.log('video player found');
        setQuality();
    } else {
        console.log('waiting for video player to load');
        setTimeout(findPlayer, 100);
    }
}

function setQuality() {
    console.log('target quality:', targetQuality);

    let origQuality = player.getPlaybackQuality();
    console.log('original quality:', origQuality);

    let qualities = player.getAvailableQualityLevels();
    console.log('available qualities:', qualities);

    let pickedQuality = targetQuality;
    if (pickedQuality == 'best') {
        pickedQuality = qualities[0];
        console.log('desired best quality is:', pickedQuality);
    }

    if (pickedQuality != origQuality) {
        console.log('setting resolution to:', pickedQuality);
        player.setPlaybackQualityRange(pickedQuality);
        console.log('new quality: ', player.getPlaybackQuality());
    } else {
        console.log('quality is already set to', pickedQuality, ", won't set anything");
    }
}

(function() {
    'use strict';
    findPlayer();
})();